package org.opentripplanner.ext.ridehailing.model;

/**
 * Enum for the provider type of ride hailing services.
 */
public enum RideHailingProvider {
  UBER,
}
