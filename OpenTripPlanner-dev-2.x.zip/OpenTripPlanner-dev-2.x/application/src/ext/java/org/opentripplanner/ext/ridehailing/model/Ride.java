package org.opentripplanner.ext.ridehailing.model;

public interface Ride {
  String rideType();
}
